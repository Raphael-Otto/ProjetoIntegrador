<script>
import MenuLateral from "@/components/MenuLateral.vue";
import CabeCalho from "@/components/CabeCalho.vue";
import PrincIpal from "@/components/PrincIpal.vue";
import RodApe from "@/components/RodApe.vue";
export default {
  components: { MenuLateral, CabeCalho, PrincIpal, RodApe },
};
</script>
<template>
  <MenuLateral />
  <CabeCalho />
  <PrincIpal />
  <RodApe />
</template>
<style></style>
