<script>
export default {};
</script>
<template>
  <header id="header">
    <div class="titulo">Receitas.com</div>
  </header>
</template>
<style>
#header {
  grid-area: header;
  text-align: center;
  font-size: 80px;
  background-color: #fcbcd5;
}

.titulo {
  font-family: "Oleo Script", cursive;
  color: azure;
}
</style>
