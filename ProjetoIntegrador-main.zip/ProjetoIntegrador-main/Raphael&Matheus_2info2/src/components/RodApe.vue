<script>
export default {};
</script>
<template>
  <footer id="footer"></footer>
</template>
<style>
#footer {
  grid-area: footer;
  background-color: #ffeff5;
}
</style>
