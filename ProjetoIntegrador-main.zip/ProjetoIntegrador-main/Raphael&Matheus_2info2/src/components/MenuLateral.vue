<script>
export default {};
</script>
<template>
  <aside id="sidenav">
    <div class="lista">
      <p>BOLO</p>
      <p>BISCOITO</p>
      <p>CARNE</p>
      <p>MOLHO</p>
      <p>PIZZA</p>
      <p>CUPCAKE</p>
      <p>BEBIDAS</p>
      <p>SALADA</p>
    </div>
  </aside>
</template>
<style>
#sidenav {
  grid-area: sidenav;
  background-color: #ffdae8;
}

.lista {
  margin-left: 30px;
  font-size: 30px;
  font-family: "Paytone One", sans-serif;
  color: azure;
}
</style>
