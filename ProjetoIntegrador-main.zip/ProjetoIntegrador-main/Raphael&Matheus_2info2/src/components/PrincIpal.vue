<script>
export default {};
</script>
<template>
  <main class="content">
    <div class="carne">
      <img src="/src/assets/Images/Bife.jpeg" />
      <p class="NomesReceitas">Bife acebolado</p>
    </div>

    <div class="bolo">
      <img src="/src/assets/Images/Bolo.jpeg" />
      <p class="NomesReceitas">Bolo Simples</p>
    </div>

    <div class="BoloChocolate">
      <img src="/src/assets/Images/BoloChocolate.jpeg" />
      <p class="NomesReceitas">Bolo de Chocolate</p>
    </div>

    <div class="BoloMorango">
      <img src="/src/assets/Images/BoloMorangoChantilly.jpeg" />
      <p class="NomesReceitas">Bolo de Morango</p>
    </div>

    <div class="Cookie">
      <img src="/src/assets/Images/Cookie.jpeg" />
      <p class="NomesReceitas">Cookie com Chocolate</p>
    </div>

    <div class="PizzaPepperoni">
      <img src="/src/assets/Images/Pizza.jpeg" />
      <p class="NomesReceitas">Pizza de Pepperoni</p>
    </div>

    <div class="Mimosa">
      <img src="/src/assets/Images/Mimosa.jpg" />
      <p class="NomesReceitas">Mimosa</p>
    </div>

    <div class="MolhoBranco">
      <img src="/src/assets/Images/MolhoBranco.jpeg" />
      <p class="NomesReceitas">Molho Branco</p>
    </div>

    <div class="Kombucha">
      <img src="/src/assets/Images/Kombucha.jpg" />
      <p class="NomesReceitas">Kombucha</p>
    </div>

    <div class="Cupcake">
      <img src="/src/assets/Images/Cupcake.jpeg" />
      <p class="NomesReceitas">Cupcake</p>
    </div>

    <div class="SaladaCoreana">
      <img src="/src/assets/Images/SaladaCoreana.jpeg" />
      <p class="NomesReceitas">Salada Coreana</p>
    </div>

    <div class="SalmaoFrito">
      <img src="/src/assets/Images/SalmaoFrito.jpg" />
      <p class="NomesReceitas">Salmão Frito</p>
    </div>
  </main>
</template>
<style>
.content {
  grid-area: content;
  border: 2px solid rgb(255, 255, 255);
}
.NomesReceitas {
  font-family: "Paytone One", sans-serif;
  font-size: 25px;
  color: azure;
}
.carne {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.bolo {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.BoloChocolate {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.BoloMorango {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.Cookie {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.PizzaPepperoni {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.Mimosa {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.MolhoBranco {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.Kombucha {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.Cupcake {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.SaladaCoreana {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
.SalmaoFrito {
  margin: 10px;
  width: 20.75%;
  padding: 10px;
  background-color: #fcbcd5;
  float: left;
}
</style>
